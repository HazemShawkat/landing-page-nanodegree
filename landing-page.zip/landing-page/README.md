# Landing Page Project
This is the landing page project readme.


## Languages used:
- HTML
- CSS
- JavaScript

## functionalities

- navigation
- the dynamic active class
- the scrolling effect

## what we learnt

in this project we converted the static web project to a dynamic project.

## how to use the project
- open the browser
- click ctrl+o
navigate to your index.html
open index.html

